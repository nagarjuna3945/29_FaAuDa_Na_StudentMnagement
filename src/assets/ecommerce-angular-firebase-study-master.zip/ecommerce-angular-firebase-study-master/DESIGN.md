# User
## User Registration
  > Email & Password Sign Up
  - createUserWithEmailAndPassword()
    - Initiate registration
    - Store to inCompleteResiter/unknownUsers collection
    - Funciton to Clean entry after every 3 days/1 week
    - Function to send Email request
    - Angular: Expose page to accept activation url with token
    -
  2.


# Query
