## Configurations

## Email
> firebase functions:config:set gmail.email="<username>" gmail.password="<pwd>"

## Multiple funtions an firebase projects
> https://firebase.googleblog.com/2016/07/deploy-to-multiple-environments-with.html