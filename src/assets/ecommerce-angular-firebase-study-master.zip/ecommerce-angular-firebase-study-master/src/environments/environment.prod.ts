export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAaPXufaWhSXz73GWzuNERRJx7zNuK29fo',
    authDomain: 'ecommerce-angular-firebase.firebaseapp.com',
    databaseURL: 'https://ecommerce-angular-firebase.firebaseio.com',
    projectId: 'ecommerce-angular-firebase',
    storageBucket: 'ecommerce-angular-firebase.appspot.com',
    messagingSenderId: '739633781630'
  }
};
